--------------------
extLinkRedirector
--------------------
Author: Kirill Korovin <antiborsh@gmail.com>
--------------------

Plug-in for external links